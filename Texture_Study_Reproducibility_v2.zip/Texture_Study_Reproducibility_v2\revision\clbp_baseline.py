"""Completed LBP (CLBP_S/M/C) baseline for the IJACSA revision.

Descriptor (Guo, Zhang and Zhang, IEEE TIP 2010):
  for (P, R) in {(8,1), (16,2), (24,3)} with the same circular sampling, bilinear
  interpolation and boundary handling as the LBP branch of experiment.py:
    S: rotation-invariant uniform code of sign(g_p - g_c)                (P+2 values)
    M: rotation-invariant uniform code of |g_p - g_c| >= mean magnitude  (P+2 values)
       (threshold = mean |g_p - g_c| over all valid centers of the image for that (P,R))
    C: 1[g_c >= mean grey level of the whole image]                      (2 values)
  joint S/M/C histogram with (P+2)^2 * 2 bins -> 200 + 648 + 1352 = 2200 bins.
  Each histogram is normalized to unit sum and square-root transformed; the three are
  concatenated and divided by sqrt(3) (unit Euclidean norm), exactly as for LBP.

Evaluation: RBF-SVM, nested selection by mean inner-validation accuracy on the recorded
outer/inner partitions; one inner score table on the extended grid is computed and the
original-grid result is obtained by restricting selection to gamma = 1, C in {0.1, 1, 10}.

Native use:
  python clbp_baseline.py <results-dir> <kth1-image-dir> <kth2-image-dir>
"""
import io, json, math, sys, time
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

RADII = [(8, 1), (16, 2), (24, 3)]
GRIDS = {'original': dict(gammas=[1.], cs=[.1, 1, 10]),
         'extended': dict(gammas=[.1, .3, 1., 3., 10.], cs=[.1, 1, 10, 100]),
         'wide': dict(gammas=[.1, .3, 1., 3., 10., 30.], cs=[.1, 1, 10, 100, 1000])}
PROTOCOLS = {'random-image': 'kth1', 'held-scale': 'kth1',
             'held-illumination': 'kth1', 'held-specimen': 'kth2'}
LOG = lambda *a: print(*a, flush=True)


def _neighbors(x, p, r):
    center = x[r:-r, r:-r]
    h, w = center.shape
    out = []
    for k in range(p):
        angle = 2 * np.pi * k / p
        dy, dx = round(-r * np.sin(angle), 12), round(r * np.cos(angle), 12)
        iy, ix = int(np.floor(dy)), int(np.floor(dx))
        fy, fx = dy - iy, dx - ix
        y0, x0 = r + iy, r + ix
        q = (1 - fy) * (1 - fx) * x[y0:y0 + h, x0:x0 + w]
        if fx:
            q = q + (1 - fy) * fx * x[y0:y0 + h, x0 + 1:x0 + w + 1]
        if fy:
            q = q + fy * (1 - fx) * x[y0 + 1:y0 + h + 1, x0:x0 + w]
        if fy and fx:
            q = q + fy * fx * x[y0 + 1:y0 + h + 1, x0 + 1:x0 + w + 1]
        out.append(q)
    return center, np.asarray(out)


def _riu2(bits, p):
    trans = np.sum(bits != np.roll(bits, 1, axis=0), axis=0)
    return np.where(trans <= 2, bits.sum(axis=0), p + 1)


def clbp(x):
    """x: 2-D grey image in [0, 1]. Returns the 2200-dimensional CLBP_S/M/C vector."""
    hist = []
    for p, r in RADII:
        c, nb = _neighbors(x, p, r)
        d = nb - c
        s = _riu2(d >= 0, p)
        m = np.abs(d)
        mcode = _riu2(m >= m.mean(), p)
        ccode = (c >= x.mean()).astype(int)
        code = (s * (p + 2) + mcode) * 2 + ccode
        h = np.bincount(code.ravel(), minlength=(p + 2) * (p + 2) * 2).astype(float)
        hist.append(np.sqrt(h / h.sum()))
    return np.concatenate(hist) / np.sqrt(3)


def image_to_grey(raw_bytes):
    from PIL import Image
    return np.asarray(Image.open(io.BytesIO(raw_bytes)).convert('L'), dtype=float) / 255


def sqdist(H):
    """Pairwise squared Euclidean distances, computed once per dataset."""
    n2 = (H * H).sum(1)
    D = n2[:, None] + n2[None, :] - 2 * (H @ H.T)
    np.maximum(D, 0, out=D)
    return D


def _fit_predict(D, y, a, b, g, c):
    """RBF-SVM with the kernel exp(-g * D) precomputed from cached distances;
    mathematically identical to SVC(kernel='rbf', gamma=g) on the same features."""
    m = SVC(C=c, kernel='precomputed', cache_size=1000).fit(np.exp(-g * D[np.ix_(a, a)]), y[a])
    return m.predict(np.exp(-g * D[np.ix_(b, a)])), len(m.support_)


def evaluate(H, y, splits, protocol, D=None):
    """Nested RBF-SVM selection on CLBP histograms for both grids."""
    G, CS = GRIDS['wide']['gammas'], GRIDS['wide']['cs']
    D = sqdist(H) if D is None else D
    records = []
    for sp in splits:
        t0 = time.time()
        tr, te = np.array(sp['train']), np.array(sp['test'])
        inner = [(np.array(d['train']), np.array(d['validation'])) for d in sp['inner']]
        table = {}
        for a, b in inner:
            for g in G:
                for c in CS:
                    pred, _ = _fit_predict(D, y, a, b, g, c)
                    table.setdefault((g, c), []).append(accuracy_score(y[b], pred))
        final = {}
        for grid, spec in GRIDS.items():
            best = bestkey = None
            for (g, c), s in table.items():
                if g not in spec['gammas'] or c not in spec['cs']:
                    continue
                key = (float(np.mean(s)), -c, -abs(math.log(g)))
                if bestkey is None or key > bestkey:
                    bestkey, best = key, (g, c)
            if best not in final:
                final[best] = _fit_predict(D, y, tr, te, *best)
            pred, nsv = final[best]
            records.append(dict(protocol=protocol, fold=sp['fold'], method='CLBP', grid=grid,
                                gamma=best[0], C=best[1], inner_scores=table[best],
                                accuracy=float(accuracy_score(y[te], pred)),
                                macro_f1=float(f1_score(y[te], pred, average='macro')),
                                support_vectors=nsv, truth=y[te].tolist(),
                                prediction=pred.tolist(), test=te.tolist()))
        LOG(f'CLBP {protocol} fold {sp["fold"]} done in {time.time() - t0:.1f} s: ' +
            ', '.join(f'{r["grid"]} {100 * r["accuracy"]:.2f} (g={r["gamma"]}, C={r["C"]})'
                      for r in records[-2:]))
    return records


def summarize(records):
    out = {}
    for p in sorted({r['protocol'] for r in records}):
        out[p] = {}
        for grid in GRIDS:
            rows = sorted([r for r in records if r['protocol'] == p and r['grid'] == grid],
                          key=lambda r: r['fold'])
            acc = np.array([r['accuracy'] for r in rows])
            out[p][grid] = dict(mean_accuracy=float(acc.mean()),
                                sd_accuracy=float(acc.std(ddof=1)),
                                minimum_accuracy=float(acc.min()),
                                mean_f1=float(np.mean([r['macro_f1'] for r in rows])),
                                fold_accuracy=acc.tolist(),
                                gamma=[r['gamma'] for r in rows], C=[r['C'] for r in rows])
    return out


if __name__ == '__main__':
    from pathlib import Path
    root, img1, img2 = map(Path, sys.argv[1:4])
    out = Path(__file__).resolve().parent / 'results_revision'
    out.mkdir(exist_ok=True)
    feats, labels = {}, {}
    for ds, img in (('kth1', img1), ('kth2', img2)):
        manifest = json.loads((root / f'{ds}_manifest.json').read_text())
        classes = sorted({m['label'] for m in manifest})
        labels[ds] = np.array([classes.index(m['label']) for m in manifest])
        feats[ds] = np.array([clbp(image_to_grey((img / m['path']).read_bytes())) for m in manifest])
        np.save(out / f'clbp_{ds}.npy', feats[ds].astype(np.float32))
    records = []
    for p, ds in PROTOCOLS.items():
        records += evaluate(feats[ds], labels[ds], json.loads((root / f'{p}_splits.json').read_text()), p)
    (out / 'clbp_records.json').write_text(json.dumps(records))
    (out / 'clbp_summary.json').write_text(json.dumps(summarize(records), indent=2))
