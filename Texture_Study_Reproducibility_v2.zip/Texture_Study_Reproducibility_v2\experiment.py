"""Compact texture descriptors; nested acquisition/sample-held-out evaluation."""
import os
os.environ['OMP_NUM_THREADS']='1'
import json,re,time,hashlib,platform,tarfile
from pathlib import Path
import numpy as np
from PIL import Image
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold,LeaveOneGroupOut
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score,f1_score,confusion_matrix
import sklearn,scipy,PIL,matplotlib
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
WEIGHTS=[0,.25,.5,.75,1];CS=[.1,1,10]

def wave(x):
    out=[]
    for level in range(3):
        x=x[:x.shape[0]//2*2,:x.shape[1]//2*2]
        a,b,c,d=x[::2,::2],x[::2,1::2],x[1::2,::2],x[1::2,1::2]
        for z in [(a+b-c-d)/2,(a-b+c-d)/2,(a-b-c+d)/2]:
            out.extend([np.log(np.mean(abs(z))+1e-6),np.log(np.sqrt(np.mean(z*z))+1e-6)])
        x=(a+b+c+d)/2
    return np.asarray(out)

def lbp(x):
    hist=[]
    for p,r in [(8,1),(16,2),(24,3)]:
        center=x[r:-r,r:-r];bits=[]
        h,w=center.shape
        for k in range(p):
            angle=2*np.pi*k/p
            dy,dx=round(-r*np.sin(angle),12),round(r*np.cos(angle),12)
            iy,ix=int(np.floor(dy)),int(np.floor(dx));fy,fx=dy-iy,dx-ix
            y0,x0=r+iy,r+ix
            q=(1-fy)*(1-fx)*x[y0:y0+h,x0:x0+w]
            if fx:q=q+(1-fy)*fx*x[y0:y0+h,x0+1:x0+w+1]
            if fy:q=q+fy*(1-fx)*x[y0+1:y0+h+1,x0:x0+w]
            if fy and fx:q=q+fy*fx*x[y0+1:y0+h+1,x0+1:x0+w+1]
            bits.append(q>=center)
        bits=np.asarray(bits);trans=np.sum(bits!=np.roll(bits,1,axis=0),axis=0)
        codes=np.where(trans<=2,bits.sum(axis=0),p+1)
        h=np.bincount(codes.ravel(),minlength=p+2).astype(float);hist.extend(np.sqrt(h/h.sum())/np.sqrt(3))
    return np.asarray(hist)

def load(which):
    archive=ROOT/'data'/('kth_tips_grey_200x200.tar' if which=='kth1' else 'kth-tips2-b_col_200x200.tar')
    directory=ROOT/'data'/which
    if not directory.exists():
        with tarfile.open(archive) as t:t.extractall(directory,filter='data')
    files=sorted(directory.rglob('*.png'));assert len(files)==(810 if which=='kth1' else 4752),(which,len(files))
    manifest=[]
    cache=OUT/(which+'_features.npz')
    for f in files:
        m=re.search(r'scale_(\d+)_im_(\d+)',f.name);assert m,f
        label=f.parent.name if which=='kth1' else f.parent.parent.name
        sample=0 if which=='kth1' else 'abcd'.index(f.parent.name[-1])
        manifest.append(dict(path=f.relative_to(directory).as_posix(),label=label,scale=int(m[1]),image=int(m[2]),sample=sample,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
    if cache.exists():
        a=np.load(cache);raw,norm,hist=[a[k] for k in ['raw','norm','hist']]
    else:
        raw=[];norm=[];hist=[];times=[]
        for i,f in enumerate(files):
            # Preserve native crop dimensions; RGB uses Pillow's fixed luminance conversion.
            x=np.asarray(Image.open(f).convert('L'),dtype=float)/255
            start=time.perf_counter();raw.append(wave(x));t1=time.perf_counter()
            z=(x-x.mean())/max(x.std(),1e-6);norm.append(wave(z));t2=time.perf_counter()
            hist.append(lbp(x));t3=time.perf_counter();times.append([t1-start,t2-t1,t3-t2])
            if i%250==0:print(which,'features',i,len(files),flush=True)
        raw,norm,hist=map(np.asarray,[raw,norm,hist]);np.savez_compressed(cache,raw=raw,norm=norm,hist=hist)
        (OUT/(which+'_timing.json')).write_text(json.dumps(dict(median_ms=(np.median(times,axis=0)*1000).tolist(),p90_ms=(np.percentile(times,90,axis=0)*1000).tolist())))
    (OUT/(which+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
    classes=sorted({m['label'] for m in manifest});y=np.array([classes.index(m['label']) for m in manifest])
    assert all(np.all(np.isfinite(x)) for x in [raw,norm,hist])
    return dict(raw=raw,norm=norm,hist=hist),y,manifest,classes

def represent(features,train,test,method,w):
    if method in ['DWT-raw','DWT-normalized']:
        z=features['raw' if method=='DWT-raw' else 'norm'];s=StandardScaler().fit(z[train]);return s.transform(z[train])/np.sqrt(18),s.transform(z[test])/np.sqrt(18)
    if method=='LBP':return features['hist'][train],features['hist'][test]
    z=features['norm'];s=StandardScaler().fit(z[train])
    return tuple(np.hstack([np.sqrt(w)*s.transform(z[ix])/np.sqrt(18),np.sqrt(1-w)*features['hist'][ix]]) for ix in [train,test])

def run(features,y,groups,protocol,classes):
    outer=list(StratifiedKFold(5,shuffle=True,random_state=20261004).split(y,y)) if groups is None else list(LeaveOneGroupOut().split(y,y,groups))
    methods=['DWT-raw','DWT-normalized','LBP','Fixed-fusion','Mean-fusion','Robust-fusion'];records=[];splits=[]
    for fold,(train,test) in enumerate(outer):
        inner=list(StratifiedKFold(3,shuffle=True,random_state=73+fold).split(y[train],y[train])) if groups is None else list(LeaveOneGroupOut().split(y[train],y[train],groups[train]))
        splits.append(dict(fold=fold,train=train.tolist(),test=test.tolist(),inner=[dict(train=train[a].tolist(),validation=train[b].tolist()) for a,b in inner]))
        for method in methods:
            ws=WEIGHTS if method in ['Mean-fusion','Robust-fusion'] else [.5]
            best=None;bestkey=None
            for w in ws:
                for c in CS:
                    scores=[]
                    for a,b in inner:
                        xt,xv=represent(features,train[a],train[b],method,w)
                        model=SVC(C=c,kernel='rbf',gamma=1.,cache_size=300).fit(xt,y[train[a]])
                        scores.append(accuracy_score(y[train[b]],model.predict(xv)))
                    # Worst-condition validation only for Robust-fusion; baseline uses mean.
                    key=(min(scores),np.mean(scores),-c,-w) if method=='Robust-fusion' else (np.mean(scores),-c)
                    if bestkey is None or key>bestkey:bestkey=key;best=(w,c,scores)
            w,c,scores=best;xt,xv=represent(features,train,test,method,w);start=time.perf_counter()
            model=SVC(C=c,kernel='rbf',gamma=1.,cache_size=300).fit(xt,y[train]);fit=time.perf_counter()-start
            start=time.perf_counter();pred=model.predict(xv);elapsed=time.perf_counter()-start
            records.append(dict(protocol=protocol,fold=fold,held_group=None if groups is None else int(groups[test[0]]),method=method,weight=w,C=c,inner_scores=scores,accuracy=accuracy_score(y[test],pred),macro_f1=f1_score(y[test],pred,average='macro'),truth=y[test].tolist(),prediction=pred.tolist(),test=test.tolist(),fit_s=fit,predict_ms_per_image=elapsed/len(test)*1000,support_vectors=len(model.support_)))
            (OUT/(protocol+'_records.json')).write_text(json.dumps(records,indent=2))
            print(protocol,fold,method,'acc',round(records[-1]['accuracy'],4),'w',w,'C',c,flush=True)
    (OUT/(protocol+'_splits.json')).write_text(json.dumps(splits))
    return records

def main():
    allrecords=[]
    for which in ['kth1','kth2']:
        features,y,manifest,classes=load(which)
        if which=='kth1':
            protocols=[('random-image',None),('held-scale',np.array([m['scale'] for m in manifest])),('held-illumination',np.array([(m['image']-1)%3 for m in manifest]))]
        else:protocols=[('held-specimen',np.array([m['sample'] for m in manifest]))]
        for protocol,groups in protocols:allrecords+=run(features,y,groups,protocol,classes)
    (OUT/'all_records.json').write_text(json.dumps(allrecords,indent=2))
    versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,Pillow=PIL.__version__,matplotlib=matplotlib.__version__,platform=platform.platform())
    (OUT/'versions.json').write_text(json.dumps(versions,indent=2))
    summary={}
    for protocol in sorted({r['protocol'] for r in allrecords}):
        summary[protocol]={}
        for method in sorted({r['method'] for r in allrecords}):
            rows=[r for r in allrecords if r['protocol']==protocol and r['method']==method];acc=np.array([r['accuracy'] for r in rows])
            summary[protocol][method]=dict(mean_accuracy=acc.mean(),sd_accuracy=acc.std(ddof=1),minimum_accuracy=acc.min(),mean_f1=np.mean([r['macro_f1'] for r in rows]),weights=[r['weight'] for r in rows],C=[r['C'] for r in rows])
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
