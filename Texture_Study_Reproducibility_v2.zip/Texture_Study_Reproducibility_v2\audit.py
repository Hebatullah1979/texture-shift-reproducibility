"""Check scientific invariants and recorded test/train separation."""
import json
from pathlib import Path
import numpy as np
import experiment as e
root=Path(__file__).resolve().parent
x=np.random.default_rng(192).uniform(.1,.7,(200,201));transformed=.7*x+.1
norm=lambda a:(a-a.mean())/a.std()
assert np.allclose(e.wave(norm(x)),e.wave(norm(transformed)),atol=1e-9)
assert np.allclose(e.lbp(x),e.lbp(transformed),atol=1e-12)
assert len(e.wave(x))==18 and len(e.lbp(x))==54
assert abs(np.linalg.norm(e.lbp(x))-1)<1e-12
checks=[]
for protocol in ['random-image','held-scale','held-illumination','held-specimen']:
    splits=json.loads((root/'results'/(protocol+'_splits.json')).read_text())
    manifest=json.loads((root/'results'/('kth2_manifest.json' if protocol=='held-specimen' else 'kth1_manifest.json')).read_text())
    seen=[]
    def group(i):
        m=manifest[i]
        return m['sample'] if protocol=='held-specimen' else m['scale'] if protocol=='held-scale' else (m['image']-1)%3
    for s in splits:
        train,test=set(s['train']),set(s['test']);assert not train&test;assert len(train|test)==len(manifest)
        seen.extend(test)
        assert {manifest[i]['sha256'] for i in train}.isdisjoint({manifest[i]['sha256'] for i in test}),('duplicate image across split',protocol)
        if protocol!='random-image':assert {group(i) for i in train}.isdisjoint({group(i) for i in test})
        for inner in s['inner']:
            a,b=set(inner['train']),set(inner['validation']);assert not a&b;assert a|b==train
            if protocol!='random-image':assert {group(i) for i in a}.isdisjoint({group(i) for i in b})
    assert sorted(seen)==list(range(len(manifest)))
    rr=json.loads((root/'results'/(protocol+'_records.json')).read_text())
    assert len(rr)==len(splits)*6
    for r in rr:
        assert r['test']==splits[r['fold']]['test']
        assert np.isclose(np.mean(np.array(r['truth'])==r['prediction']),r['accuracy'])
    checks.append(dict(protocol=protocol,folds=len(splits),test_images=len(seen),passed=True))
result=dict(positive_affine_invariance=True,dimensions_verified=True,partition_checks=checks)
(root/'results'/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
