"""Revision analyses for the IJACSA resubmission.

Modes
  repro     Re-runs the original nested selection (gamma = 1, C in {0.1, 1, 10}) on the
            cached features and recorded splits; must reproduce results/summary.json.
  grid      Nested selection over a wider RBF grid: gamma in {0.1, 0.3, 1, 3, 10},
            C in {0.1, 1, 10, 100}; gamma is selected jointly with C (and alpha) using
            the same inner partitions and validation objectives as the original study.
  multi     One pass over the widest grid (gamma up to 30, C up to 1000) with precomputed
            RBF kernels; selection is repeated within the original, extended and wide
            sub-grids, so the first two must reproduce the repro and grid modes exactly.
  variance  Fold-level paired differences and class-by-fold sign tests on recorded
            predictions (original records, or grid records when supplied).

No images are needed: features come from results/kth1_features.npz and
results/kth2_features.npz, partitions from results/<protocol>_splits.json.

Native use:  python revision_analysis.py <results-dir> repro|grid|variance [protocol ...]
"""
import io, json, math, sys, time
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

WEIGHTS = [0, .25, .5, .75, 1]
GRIDS = {'repro': dict(gammas=[1.], cs=[.1, 1, 10]),
         'grid': dict(gammas=[.1, .3, 1., 3., 10.], cs=[.1, 1, 10, 100])}
PROTOCOLS = {'random-image': 'kth1', 'held-scale': 'kth1',
             'held-illumination': 'kth1', 'held-specimen': 'kth2'}
METHODS = ['DWT-raw', 'DWT-normalized', 'LBP', 'Fixed-fusion', 'Mean-fusion', 'Robust-fusion']
LOG = lambda *a: print(*a, flush=True)


def labels(manifest):
    classes = sorted({m['label'] for m in manifest})
    return np.array([classes.index(m['label']) for m in manifest]), classes


def rep(F, tr, te, kind, w):
    """'raw': standardized raw DWT / sqrt(18).  'fus', w: Eq. (4) fusion.
    w = 1 is the normalized-DWT baseline and w = 0 the LBP baseline (zero-weight
    columns are dropped; RBF distances are unchanged)."""
    if kind == 'raw':
        s = StandardScaler().fit(F['raw'][tr])
        return s.transform(F['raw'][tr]) / np.sqrt(18), s.transform(F['raw'][te]) / np.sqrt(18)
    s = StandardScaler().fit(F['norm'][tr])
    out = []
    for ix in (tr, te):
        parts = []
        if w > 0:
            parts.append(np.sqrt(w) * s.transform(F['norm'][ix]) / np.sqrt(18))
        if w < 1:
            parts.append(np.sqrt(1 - w) * F['hist'][ix])
        out.append(np.hstack(parts))
    return out


def admissible(method, kind, w):
    if method == 'DWT-raw':
        return kind == 'raw'
    if kind == 'raw':
        return False
    return {'DWT-normalized': w == 1, 'LBP': w == 0, 'Fixed-fusion': w == .5}.get(method, True)


def select(table, method):
    """Original tie rules; gamma ties prefer the value closest to the original gamma = 1."""
    best = bestkey = None
    for (kind, w, g, c), s in table.items():
        if not admissible(method, kind, w):
            continue
        ww = 0 if w is None else w
        mean, mn = float(np.mean(s)), float(np.min(s))
        key = ((mn, mean, -c, -ww, -abs(math.log(g))) if method == 'Robust-fusion'
               else (mean, -c, -ww, -abs(math.log(g))))
        if bestkey is None or key > bestkey:
            bestkey, best = key, (kind, w, g, c)
    return best


def run_protocol(F, y, splits, protocol, gammas, cs):
    reps = [('raw', None)] + [('fus', w) for w in WEIGHTS]
    records = []
    for sp in splits:
        t0 = time.time()
        tr, te = np.array(sp['train']), np.array(sp['test'])
        inner = [(np.array(d['train']), np.array(d['validation'])) for d in sp['inner']]
        table = {}
        for kind, w in reps:
            for a, b in inner:
                xt, xv = rep(F, a, b, kind, w)
                for g in gammas:
                    for c in cs:
                        m = SVC(C=c, kernel='rbf', gamma=g, cache_size=500).fit(xt, y[a])
                        table.setdefault((kind, w, g, c), []).append(accuracy_score(y[b], m.predict(xv)))
        final = {}
        for method in METHODS:
            sel = select(table, method)
            if sel not in final:
                kind, w, g, c = sel
                xt, xv = rep(F, tr, te, kind, w)
                m = SVC(C=c, kernel='rbf', gamma=g, cache_size=500).fit(xt, y[tr])
                final[sel] = (m.predict(xv), len(m.support_))
            pred, nsv = final[sel]
            kind, w, g, c = sel
            records.append(dict(protocol=protocol, fold=sp['fold'], method=method,
                                weight=w if method in ('Fixed-fusion', 'Mean-fusion', 'Robust-fusion') else None,
                                gamma=g, C=c, inner_scores=table[sel],
                                accuracy=float(accuracy_score(y[te], pred)),
                                macro_f1=float(f1_score(y[te], pred, average='macro')),
                                support_vectors=nsv, truth=y[te].tolist(),
                                prediction=pred.tolist(), test=te.tolist()))
        LOG(f'{protocol} fold {sp["fold"]} done in {time.time() - t0:.1f} s: ' +
            ', '.join(f'{r["method"]} {100 * r["accuracy"]:.2f}' for r in records[-6:]))
    return records


MULTI = {'original': dict(gammas=[1.], cs=[.1, 1, 10]),
         'extended': dict(gammas=[.1, .3, 1., 3., 10.], cs=[.1, 1, 10, 100]),
         'wide': dict(gammas=[.1, .3, 1., 3., 10., 30.], cs=[.1, 1, 10, 100, 1000])}


def _cross_sqdist(A, B):
    D = (A * A).sum(1)[:, None] + (B * B).sum(1)[None, :] - 2 * (A @ B.T)
    np.maximum(D, 0, out=D)
    return D


def _fit_pre(xt, yt, xv, g, c, Dtt=None, Dvt=None):
    """RBF-SVM through a precomputed kernel exp(-g * squared distance); identical in
    exact arithmetic to SVC(kernel='rbf', gamma=g), but distances are reused across the grid."""
    Dtt = _cross_sqdist(xt, xt) if Dtt is None else Dtt
    Dvt = _cross_sqdist(xv, xt) if Dvt is None else Dvt
    m = SVC(C=c, kernel='precomputed', cache_size=500).fit(np.exp(-g * Dtt), yt)
    return m.predict(np.exp(-g * Dvt)), len(m.support_)


def run_protocol_multi(F, y, splits, protocol):
    """One inner score table on the widest grid; selection is then repeated inside each
    nested sub-grid (original, extended, wide), so all three share identical fits."""
    W = MULTI['wide']
    reps = [('raw', None)] + [('fus', w) for w in WEIGHTS]
    records = []
    for sp in splits:
        t0 = time.time()
        tr, te = np.array(sp['train']), np.array(sp['test'])
        inner = [(np.array(d['train']), np.array(d['validation'])) for d in sp['inner']]
        table = {}
        for kind, w in reps:
            for a, b in inner:
                xt, xv = rep(F, a, b, kind, w)
                Dtt, Dvt = _cross_sqdist(xt, xt), _cross_sqdist(xv, xt)
                for g in W['gammas']:
                    for c in W['cs']:
                        pred, _ = _fit_pre(xt, y[a], xv, g, c, Dtt, Dvt)
                        table.setdefault((kind, w, g, c), []).append(accuracy_score(y[b], pred))
        final = {}
        for grid, spec in MULTI.items():
            sub = {k: v for k, v in table.items() if k[2] in spec['gammas'] and k[3] in spec['cs']}
            for method in METHODS:
                sel = select(sub, method)
                if sel not in final:
                    kind, w, g, c = sel
                    xt, xv = rep(F, tr, te, kind, w)
                    final[sel] = _fit_pre(xt, y[tr], xv, g, c)
                pred, nsv = final[sel]
                kind, w, g, c = sel
                records.append(dict(protocol=protocol, grid=grid, fold=sp['fold'], method=method,
                                    weight=w if method in ('Fixed-fusion', 'Mean-fusion', 'Robust-fusion') else None,
                                    gamma=g, C=c, inner_scores=table[sel],
                                    accuracy=float(accuracy_score(y[te], pred)),
                                    macro_f1=float(f1_score(y[te], pred, average='macro')),
                                    support_vectors=nsv, truth=y[te].tolist(),
                                    prediction=pred.tolist(), test=te.tolist()))
        LOG(f'{protocol} fold {sp["fold"]} done in {time.time() - t0:.1f} s: wide ' +
            ', '.join(f'{r["method"]} {100 * r["accuracy"]:.2f}' for r in records[-6:]))
    return records


def _key(r):
    return r['protocol'] + ('@' + r['grid'] if 'grid' in r else '')


def summarize(records):
    out = {}
    for p in sorted({_key(r) for r in records}):
        out[p] = {}
        for meth in METHODS:
            rows = sorted([r for r in records if _key(r) == p and r['method'] == meth], key=lambda r: r['fold'])
            if not rows:
                continue
            acc = np.array([r['accuracy'] for r in rows])
            out[p][meth] = dict(mean_accuracy=float(acc.mean()),
                                sd_accuracy=float(acc.std(ddof=1)) if len(acc) > 1 else 0.0,
                                minimum_accuracy=float(acc.min()),
                                mean_f1=float(np.mean([r['macro_f1'] for r in rows])),
                                fold_accuracy=acc.tolist(),
                                weights=[r.get('weight') for r in rows],
                                gamma=[r.get('gamma', 1.0) for r in rows],
                                C=[r['C'] for r in rows])
    return out


def sign_test(pos, neg):
    """Exact two-sided binomial sign test, ties excluded."""
    n = pos + neg
    if n == 0:
        return 1.0
    k = min(pos, neg)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)


PAIRS = [('DWT-normalized', 'DWT-raw'), ('Fixed-fusion', 'LBP'), ('Robust-fusion', 'LBP'),
         ('Robust-fusion', 'DWT-raw'), ('Mean-fusion', 'LBP'), ('Fixed-fusion', 'DWT-normalized'),
         ('Robust-fusion', 'Mean-fusion')]


def variance(records):
    """Fold-level paired differences and class-by-fold sign tests (percentage points)."""
    out = {}
    for p in sorted({_key(r) for r in records}):
        R = {(r['method'], r['fold']): r for r in records if _key(r) == p}
        folds = sorted({f for _, f in R})
        out[p] = {}
        for a, b in PAIRS:
            if (a, folds[0]) not in R or (b, folds[0]) not in R:
                continue
            d = np.array([100 * (R[a, f]['accuracy'] - R[b, f]['accuracy']) for f in folds])
            pos = neg = tie = 0
            cls_diffs = []
            for f in folds:
                t = np.array(R[a, f]['truth'])
                pa, pb = np.array(R[a, f]['prediction']), np.array(R[b, f]['prediction'])
                for k in np.unique(t):
                    m = t == k
                    dd = 100 * (np.mean(pa[m] == k) - np.mean(pb[m] == k))
                    cls_diffs.append(dd)
                    pos += dd > 1e-9; neg += dd < -1e-9; tie += abs(dd) <= 1e-9
            # discordant image pairs pooled over folds (descriptive; images are correlated)
            n01 = n10 = 0
            for f in folds:
                t = np.array(R[a, f]['truth'])
                ca = np.array(R[a, f]['prediction']) == t
                cb = np.array(R[b, f]['prediction']) == t
                n10 += int(np.sum(ca & ~cb)); n01 += int(np.sum(~ca & cb))
            out[p][f'{a} - {b}'] = dict(
                fold_diff=d.round(2).tolist(), mean_diff=round(float(d.mean()), 2),
                sd_diff=round(float(d.std(ddof=1)), 2) if len(d) > 1 else 0.0,
                folds_positive=int((d > 1e-9).sum()), folds=len(d),
                min_fold_sign_test_p=round(2 / 2 ** len(d), 4),
                class_fold_units=len(cls_diffs), class_fold_pos=int(pos), class_fold_neg=int(neg),
                class_fold_tie=int(tie), class_fold_sign_p=round(sign_test(int(pos), int(neg)), 4),
                discordant_a_only=n10, discordant_b_only=n01)
    return out


def load_inputs(get_bytes, get_text):
    F = {k: dict(np.load(io.BytesIO(get_bytes(f'{k}_features.npz')))) for k in ('kth1', 'kth2')}
    Y = {k: labels(json.loads(get_text(f'{k}_manifest.json')))[0] for k in ('kth1', 'kth2')}
    return F, Y


def run_mode(mode, get_bytes, get_text, protocols=None):
    if mode == 'variance':
        return variance(json.loads(get_text('all_records.json')))
    F, Y = load_inputs(get_bytes, get_text)
    records = []
    for p in protocols or list(PROTOCOLS):
        ds = PROTOCOLS[p]
        splits = json.loads(get_text(f'{p}_splits.json'))
        if mode == 'multi':
            records += run_protocol_multi(F[ds], Y[ds], splits, p)
        else:
            records += run_protocol(F[ds], Y[ds], splits, p, **GRIDS[mode])
    return records


if __name__ == '__main__':
    from pathlib import Path
    root, mode, protos = Path(sys.argv[1]), sys.argv[2], sys.argv[3:] or None
    res = run_mode(mode, lambda n: (root / n).read_bytes(), lambda n: (root / n).read_text(), protos)
    out = Path(__file__).resolve().parent / 'results_revision'
    out.mkdir(exist_ok=True)
    if mode == 'variance':
        (out / 'variance_original.json').write_text(json.dumps(res, indent=2))
    else:
        tag = mode + ('_' + '_'.join(protos) if protos else '')
        (out / f'{tag}_records.json').write_text(json.dumps(res))
        (out / f'{tag}_summary.json').write_text(json.dumps(summarize(res), indent=2))
        (out / f'{tag}_variance.json').write_text(json.dumps(variance(res), indent=2))
    print('written to', out)
